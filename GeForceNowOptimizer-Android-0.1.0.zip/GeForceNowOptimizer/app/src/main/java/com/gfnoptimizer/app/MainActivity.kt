package com.gfnoptimizer.app

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket
import java.util.Locale

private val GfnGreen = Color(0xFF76B900)
private val Page = Color(0xFF101510)
private val Panel = Color(0xFF1B241B)
private val Muted = Color(0xFFAAB7A8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GfnApp(this) }
    }
}

data class ProbeResult(val host: String, val samples: List<Long>, val error: String? = null) {
    val average: Long? get() = samples.takeIf { it.isNotEmpty() }?.average()?.toLong()
}

private suspend fun tcpProbe(host: String, port: Int = 443): ProbeResult =
    withContext(Dispatchers.IO) {
        val values = mutableListOf<Long>()
        repeat(3) {
            try {
                val socket = Socket()
                val start = SystemClock.elapsedRealtime()
                socket.connect(InetSocketAddress(host, port), 2500)
                values += (SystemClock.elapsedRealtime() - start)
                socket.close()
            } catch (_: Exception) {
                // A failed TCP connection is reported as an unavailable probe, not as packet loss.
            }
        }
        ProbeResult(host, values, if (values.isEmpty()) "Sin respuesta TCP" else null)
    }

private fun connectionLabel(context: Context): String {
    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val network = cm.activeNetwork ?: return "Sin conexión"
    val caps = cm.getNetworkCapabilities(network) ?: return "Desconocida"
    return when {
        caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Datos móviles"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
        else -> "Otra conexión"
    }
}

@Composable
private fun GfnApp(context: Context) {
    val scope = rememberCoroutineScope()
    var connection by remember { mutableStateOf(connectionLabel(context)) }
    var results by remember { mutableStateOf<List<ProbeResult>>(emptyList()) }
    var testing by remember { mutableStateOf(false) }
    var queueRunning by remember { mutableStateOf(false) }
    var queueStart by remember { mutableLongStateOf(0L) }
    var queueSeconds by remember { mutableLongStateOf(0L) }
    var status by remember { mutableStateOf("Listo para diagnosticar") }

    LaunchedEffect(queueRunning) {
        while (queueRunning) {
            queueSeconds = (SystemClock.elapsedRealtime() - queueStart) / 1000L
            delay(1000)
        }
    }

    val average = results.mapNotNull { it.average }.takeIf { it.isNotEmpty() }
        ?.average()?.toLong()

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = GfnGreen,
            background = Page,
            surface = Panel,
            onPrimary = Color.Black,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Page) {
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Bolt, null, tint = GfnGreen, modifier = Modifier.size(32.dp))
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        Text("GFN OPTIMIZER", color = Color.White, fontWeight = FontWeight.Black, fontSize = 20.sp)
                        Text("NETWORK + LAUNCHER", color = Muted, fontSize = 11.sp, letterSpacing = 1.5.sp)
                    }
                    AssistChip(onClick = { connection = connectionLabel(context) }, label = { Text("Actualizar red") })
                }

                Text("CENTRO DE CONTROL", color = GfnGreen, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    MetricCard("LATENCIA TCP", average?.let { "$it ms" } ?: "--", Modifier.weight(1f))
                    MetricCard("SONDEOS", if (results.isEmpty()) "--" else "${results.sumOf { it.samples.size }}/9", Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    MetricCard("CONEXIÓN", connection, Modifier.weight(1f))
                    MetricCard("COLA OBSERVADA", formatTime(queueSeconds), Modifier.weight(1f))
                }

                PanelCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.NetworkCheck, null, tint = GfnGreen)
                        Spacer(Modifier.width(8.dp))
                        Text("Diagnóstico de red", fontWeight = FontWeight.Bold)
                    }
                    Text(
                        "Mide el tiempo de establecimiento TCP hacia servicios públicos. No equivale al ping al centro de datos de GeForce NOW.",
                        color = Muted, fontSize = 12.sp
                    )
                    Button(
                        onClick = {
                            if (!testing) {
                                scope.launch {
                                    testing = true
                                    status = "Midiendo conectividad…"
                                    connection = connectionLabel(context)
                                    results = listOf(
                                        tcpProbe("www.nvidia.com"),
                                        tcpProbe("www.cloudflare.com"),
                                        tcpProbe("www.google.com")
                                    )
                                    status = "Diagnóstico terminado"
                                    testing = false
                                }
                            }
                        },
                        enabled = !testing,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = GfnGreen, contentColor = Color.Black)
                    ) {
                        if (testing) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                        else Icon(Icons.Default.Speed, null)
                        Spacer(Modifier.width(8.dp))
                        Text(if (testing) "ANALIZANDO…" else "EJECUTAR DIAGNÓSTICO", fontWeight = FontWeight.Bold)
                    }
                    Text(status, color = Muted, fontSize = 12.sp)
                    results.forEach { r ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(r.host, color = Muted, fontSize = 12.sp)
                            Text(r.average?.let { "$it ms" } ?: (r.error ?: "N/D"), color = Color.White, fontSize = 12.sp)
                        }
                    }
                }

                PanelCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Timer, null, tint = GfnGreen)
                        Spacer(Modifier.width(8.dp))
                        Text("Cronómetro de cola", fontWeight = FontWeight.Bold)
                    }
                    Text(
                        "Inícialo cuando entres en una cola del cliente oficial. El tiempo se registra localmente; no consulta ni modifica la cola de NVIDIA.",
                        color = Muted, fontSize = 12.sp
                    )
                    Text(
                        formatTime(queueSeconds),
                        modifier = Modifier.fillMaxWidth(),
                        color = GfnGreen,
                        fontSize = 36.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                if (!queueRunning) {
                                    queueStart = SystemClock.elapsedRealtime() - queueSeconds * 1000L
                                    queueRunning = true
                                } else queueRunning = false
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = GfnGreen, contentColor = Color.Black)
                        ) { Text(if (queueRunning) "PAUSAR" else "INICIAR") }
                        OutlinedButton(
                            onClick = { queueRunning = false; queueSeconds = 0L },
                            modifier = Modifier.weight(1f)
                        ) { Text("REINICIAR") }
                    }
                }

                PanelCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Public, null, tint = GfnGreen)
                        Spacer(Modifier.width(8.dp))
                        Text("Región y cliente oficial", fontWeight = FontWeight.Bold)
                    }
                    Text(
                        "La selección de región se realiza dentro de GeForce NOW. Esta versión no adivina centros de datos ni cambia opciones internas.",
                        color = Muted, fontSize = 12.sp
                    )
                    Button(
                        onClick = {
                            val launch = context.packageManager.getLaunchIntentForPackage("com.nvidia.geforcenow")
                            if (launch != null) context.startActivity(launch)
                            else {
                                status = "No se encontró la app oficial instalada."
                                val intent = Intent(Intent.ACTION_VIEW,
                                    android.net.Uri.parse("https://www.nvidia.com/geforce-now/download/"))
                                context.startActivity(intent)
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = GfnGreen, contentColor = Color.Black)
                    ) {
                        Icon(Icons.Default.SportsEsports, null)
                        Spacer(Modifier.width(8.dp))
                        Text("ABRIR GEFORCE NOW", fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(
                        onClick = { context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Wifi, null)
                        Spacer(Modifier.width(8.dp))
                        Text("CONFIGURACIÓN WI-FI")
                    }
                }

                PanelCard {
                    Text("Recomendaciones", fontWeight = FontWeight.Bold)
                    Recommendation("Wi-Fi 5 GHz", "Preferir 5 GHz o Ethernet cuando sea posible.")
                    Recommendation("Estabilidad", "Evitar descargas, copias en la nube y streaming paralelo.")
                    Recommendation("Región", "Elegir Auto o probar manualmente la región con mejor latencia dentro del cliente.")
                    Recommendation("Calidad", "Ajustar resolución y bitrate a la capacidad estable de tu conexión.")
                }

                Text(
                    "GFN Optimizer 0.1.0 • Herramienta independiente no afiliada a NVIDIA.",
                    color = Muted, fontSize = 10.sp, modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
private fun MetricCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(label, color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text(value, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun PanelCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(11.dp), content = content)
    }
}

@Composable
private fun Recommendation(title: String, body: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(title, color = GfnGreen, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Text(body, color = Muted, fontSize = 12.sp)
    }
}

private fun formatTime(seconds: Long): String {
    val h = seconds / 3600
    val m = (seconds % 3600) / 60
    val s = seconds % 60
    return String.format(Locale.US, "%02d:%02d:%02d", h, m, s)
}
