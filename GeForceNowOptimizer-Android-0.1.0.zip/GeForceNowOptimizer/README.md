# GeForce NOW Optimizer — Android

Proyecto Android nativo inicial (Kotlin + Jetpack Compose). Aplicación complementaria e independiente; no modifica el cliente ni los servidores de NVIDIA.

## Funciones implementadas en esta base
- Panel de diagnóstico.
- Tres pruebas TCP a servicios públicos por HTTPS (NVIDIA, Cloudflare y Google).
- Detección del tipo de conexión mediante ConnectivityManager.
- Cronómetro manual de espera.
- Lanzamiento de la aplicación oficial si está instalada.
- Acceso a los ajustes Wi-Fi de Android.
- Recomendaciones básicas de calidad de streaming.

## Límites técnicos importantes
- El tiempo TCP medido no es ping al centro de datos de GeForce NOW.
- Android no expone una API pública de NVIDIA para leer la posición de cola, carga de servidores o disponibilidad por región.
- La app no puede acelerar la cola del lado del servidor.
- No automatiza clics, inicio de sesión, creación de sesiones, ni selección interna de región.
- No incluye VPN, rotación de IP, multi-cuenta, llamadas a endpoints privados ni ingeniería inversa.

## Requisitos
- Android Studio reciente.
- JDK 17.
- Android SDK Platform 36.
- Gradle 8.11.1 o compatible con Android Gradle Plugin 8.10.1.

## Compilar
Abrir la carpeta del proyecto en Android Studio, sincronizar Gradle y ejecutar `app`.
Para generar APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Próximas etapas
1. Persistencia local de pruebas y tiempos de cola (DataStore/Room).
2. Histórico de latencia/jitter con pruebas repetidas y gráficas.
3. Prueba de ancho de banda con endpoint de medición fiable y consentimiento explícito.
4. Perfiles de calidad sugeridos según estabilidad medida.
5. Exportación de diagnóstico para comparar redes y horarios.

## Nota de marca
Este proyecto no está afiliado, patrocinado ni aprobado por NVIDIA. GeForce NOW y NVIDIA son marcas de sus respectivos titulares.
